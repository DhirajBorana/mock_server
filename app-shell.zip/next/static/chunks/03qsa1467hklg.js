;!function(){try { var e="undefined"!=typeof globalThis?globalThis:"undefined"!=typeof global?global:"undefined"!=typeof window?window:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&((e._debugIds|| (e._debugIds={}))[n]="b39a10e0-261a-9294-92eb-dd1f37ae7e62")}catch(e){}}();
(globalThis.TURBOPACK||(globalThis.TURBOPACK=[])).push(["object"==typeof document?document.currentScript:void 0,195376,t=>{"use strict";t.s([],733817),t.i(733817);var o=t.i(585267);t.s(["SocketInstrumentation",()=>o.la],195376)}]);

//# debugId=b39a10e0-261a-9294-92eb-dd1f37ae7e62